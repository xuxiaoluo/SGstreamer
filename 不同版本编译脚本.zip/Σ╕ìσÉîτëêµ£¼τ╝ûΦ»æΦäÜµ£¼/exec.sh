#!/bin/bash
cd ~
path=$(pwd)

#------------------------------------------
# SVN下载工程文件
#------------------------------------------
#ZMPATH=$path/Desktop/iOS_ZIJING_2
#if [ -d $ZMPATH ];then
#    rm -rf $ZMPATH
#fi
#mkdir -p $ZMPATH
##http://172.16.0.250/svn/videoCloud/trunk/iOS_ZIJING_2
##http://172.16.0.250/svn/videoCloud/branches/ios_release_v1.8_4066
#
#svn co http://172.16.0.250/svn/videoCloud/trunk/iOS_ZIJING_2 $ZMPATH

#------------------------------------------
# 打包ipa需要的字段
#------------------------------------------
projectName=iOS_ZIJING_2
IpaFile=iOS_FILE

#------------------------------------------
# 查找桌面是否存有存放ipa的文件夹,有->删除,重新创建
#------------------------------------------
filePath="${path}/Desktop/${IpaFile}"
echo "filePath $filePath"
if [ -d $filePath ];then
    rm -rf $filePath
else
    echo "没找到"
fi

#------------------------------------------
# 打包本工程
#------------------------------------------
zj_projectPath="${path}/Desktop"
cd "${zj_projectPath}/${projectName}"
./Release.sh $projectName ZIJING

#------------------------------------------
# 打包OEM
#------------------------------------------
TargetArray=(HBZY SHT NanDian)
projectPath="${path}/Desktop/${projectName}"
for NUM in ${TargetArray[*]}
do
echo "${projectPath}/${NUM}"
    echo $NUM
    cd $projectPath
    ./$NUM/Release.sh $NUM

done

#-----------------------------------------
# 删除代码文件
#-----------------------------------------
#if [ -d $ZMPATH ];then
#    rm -rf $ZMPATH
#else
#    echo "文件不存在"
#fi

